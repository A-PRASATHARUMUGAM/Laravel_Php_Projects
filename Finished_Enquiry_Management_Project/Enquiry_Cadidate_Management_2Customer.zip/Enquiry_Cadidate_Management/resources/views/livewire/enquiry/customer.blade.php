<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Customer Enquiry</title>
  
  <!-- Bootstrap CSS -->
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">

  <!-- Bootstrap Icons -->
  <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.0/font/bootstrap-icons.css" rel="stylesheet">
</head>
<body class="bg-light">
{{-- Customer Enquiry --}}

<!-- Add Enquiry Form -->
<div class="container my-5">
  <div class="modal-dialog modal-lg mx-auto">
    
        <!-- Success Message -->
    @if(session('success'))
      <div class="alert alert-success alert-dismissible fade show" role="alert">
        {{ session('success') }}
        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
      </div>
    @endif

    <!-- Form start -->
    <form action="{{ route('customer.store') }}" method="POST" class="modal-content shadow-lg rounded-4 border-0 p-4"  >
      @csrf
      <div class="modal-header border-0 pb-0">
        <h5 class="modal-title fw-bold text-dark">Add Enquiry</h5>
      </div>

      <div class="modal-body pt-3">
        <div class="row g-4">

          <!-- Name -->
          <div class="col-md-6">
            <label for="enquiryName" class="form-label text-secondary fw-semibold small">Name</label>
            <input type="text" name="name" class="form-control form-control-lg rounded-3 shadow-sm" id="enquiryName" placeholder="Enter name" value="{{ old('name') }}" required>
            @error('name')
              <div class="text-danger small mt-1">{{ $message }}</div>
            @enderror
          </div>

          <!-- Email -->
          <div class="col-md-6">
            <label for="enquiryEmail" class="form-label text-secondary fw-semibold small">Email</label>
            <input type="email" name="email" class="form-control form-control-lg rounded-3 shadow-sm" id="enquiryEmail" placeholder="Enter email" value="{{ old('email') }}" required>
            @error('email')
              <div class="text-danger small mt-1">{{ $message }}</div>
            @enderror
          </div>

          <!-- Mobile -->
          <div class="col-md-6">
            <label for="enquiryMobile" class="form-label text-secondary fw-semibold small">Mobile</label>
            <input type="text" name="mobile" class="form-control form-control-lg rounded-3 shadow-sm" id="enquiryMobile" placeholder="Enter 10-digit mobile number" pattern="[0-9]{10}" minlength="10" maxlength="10" value="{{ old('mobile') }}" required>
            @error('mobile')
              <div class="text-danger small mt-1">{{ $message }}</div>
            @enderror
          </div>

          <!-- Company Name -->
          <div class="col-md-6">
            <label for="enquiryCompany" class="form-label text-secondary fw-semibold small">Company Name</label>
            <input type="text" name="companyname" class="form-control form-control-lg rounded-3 shadow-sm" id="enquiryCompany" placeholder="Enter company name" value="{{ old('companyname') }}">
            @error('companyname')
              <div class="text-danger small mt-1">{{ $message }}</div>
            @enderror
          </div>

          <!-- Project Requirement -->
          <div class="col-12">
            <label for="enquiryProject" class="form-label text-secondary fw-semibold small">Project Requirement</label>
            <textarea name="projectreq" class="form-control form-control-lg rounded-3 shadow-sm" id="enquiryProject" rows="4" placeholder="Describe the project">{{ old('projectreq') }}</textarea>
            @error('projectreq')
              <div class="text-danger small mt-1">{{ $message }}</div>
            @enderror
          </div>

          <!-- Status -->
          <div class="col-md-6">
            <label for="status" class="form-label text-secondary fw-semibold small">Status</label>
            <select name="status" class="form-select form-select-lg rounded-3 shadow-sm" id="status">
              <option selected disabled>Select status</option>
              <option value="new">New</option>
              <option value="contacted">Contacted</option>
              <option value="interested">Interested</option>
              <option value="followup">Follow Up</option>
              <option value="needmoreinfo">Need More Info</option>
              <option value="proposalsent">Proposal Sent</option>
              <option value="negotation">Negotation</option>
              <option value="converted">Converted</option>
              <option value="onhold">On Hold</option>
              <option value="delivered">Delivered</option>
              <option value="completed">Completed</option>
            </select>
            @error('status')
              <div class="text-danger small mt-1">{{ $message }}</div>
            @enderror
          </div>

        </div>
      </div>

      <!-- Footer -->
      <div class="modal-footer border-0 pt-3">
        <a href="{{ route('login')}}" class="btn btn-dark rounded-3 px-4 ">Cancel</a>
        <button type="submit" class="btn btn-primary rounded-3 px-4 m-2">Save Enquiry</button>
      </div>
    </form>
    <!-- Form end -->

  </div>
</div>


  <!-- Bootstrap JS -->
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>

</body>
</html>
