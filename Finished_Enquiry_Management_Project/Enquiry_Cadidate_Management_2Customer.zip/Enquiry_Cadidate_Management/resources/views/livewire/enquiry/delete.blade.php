     
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Delete Page </title>
    @livewireStyles()
</head>    

<body>
    <div class="Main-Container">
             {{-- Delete Enquirey --}}
              <!-- Confirm Delete Modal  start -->
              <div class="modal fade" id="confirmDeleteModal" tabindex="-1" aria-labelledby="confirmDeleteLabel" aria-hidden="true">
                <div class="modal-dialog modal-dialog-centered">
                  <div class="modal-content">
                    
                    <div class="modal-header">
                      <h5 class="modal-title" id="confirmDeleteLabel">Confirm Delete</h5>
                      <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                    </div>
                    
                    <div class="modal-body">
                      Are you sure you want to delete this record?
                    </div>
                    
                    <div class="modal-footer">
                      <button type="button" class="btn btn-secondary btn-sm" data-bs-dismiss="modal">Cancel</button>
                      <button type="button" class="btn btn-danger btn-sm">Yes, Delete</button>
                    </div>
                    
                  </div>
                </div>
              </div>
              <!-- Confirm Delete Modal  end -->
    </div>

     @livewireScripts()
</body>
</html>
                                               
