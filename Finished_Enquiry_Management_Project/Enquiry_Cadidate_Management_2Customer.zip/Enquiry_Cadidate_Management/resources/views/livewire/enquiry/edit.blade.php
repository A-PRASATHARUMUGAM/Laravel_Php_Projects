<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link rel="stylesheet" href="{{url('assets/css/style.css')}}" id="main-style-link">
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- Bootstrap Icons -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.0/font/bootstrap-icons.css">
    <title>Edit Page</title>
</head>    

<body>
    <div class="Main-Container py-5">

        <!-- Enquiry Details Section -->
        <div class="container-fluid">
            <div class="card shadow-sm">
                <div class="card-header">
                    <h5 class="mb-0">Edit Enquiry Details</h5>
                </div>
                <div class="card-body">

                    @if (session()->has('success'))
                        <div class="alert alert-success">
                            {{ session()->get('success') }}
                        </div>
                    @endif

                    <form action="{{ route('enquiry.update', $editData->id) }}" method="POST">
                        @csrf
                        @method('PUT')

                        <div class="row g-3">

                            <div class="col-md-6">
                                <label class="form-label">Name</label>
                                <input type="text" name="name" class="form-control" value="{{ old('name', $editData->name) }}">
                            </div>

                            <div class="col-md-6">
                                <label class="form-label">Email</label>
                                <input type="email" name="email" class="form-control" value="{{ old('email', $editData->email) }}">
                            </div>

                            <div class="col-md-6">
                                <label class="form-label">Mobile</label>
                                <input type="text" name="mobile" class="form-control" value="{{ old('mobile', $editData->mobile) }}">
                            </div>

                            <div class="col-md-6">
                                <label class="form-label">Company Name</label>
                                <input type="text" name="companyname" class="form-control" value="{{ old('companyname', $editData->companyname) }}">
                            </div>

                            <div class="col-12">
                                <label class="form-label">Project Requirement</label>
                                <textarea name="projectreq" class="form-control" rows="3">{{ old('projectreq', $editData->projectreq) }}</textarea>
                            </div>

                            <div class="col-md-6">
                                <label class="form-label">Status</label>
                                <select name="status" class="form-select">
                                    <option disabled>Select status</option>
                                    <option value="new" {{ old('status', $editData->status) == 'new' ? 'selected' : '' }}>New</option>
                                    <option value="contacted" {{ old('status', $editData->status) == 'contacted' ? 'selected' : '' }}>Contacted</option>
                                    <option value="interested" {{ old('status', $editData->status) == 'interested' ? 'selected' : '' }}>Interested</option>
                                    <option value="followup" {{ old('status', $editData->status) == 'followup' ? 'selected' : '' }}>Follow Up</option>
                                    <option value="needmoreinfo" {{ old('status', $editData->status) == 'needmoreinfo' ? 'selected' : '' }}>Need More Info</option>
                                    <option value="proposalsent" {{ old('status', $editData->status) == 'proposalsent' ? 'selected' : '' }}>Proposal Sent</option>
                                    <option value="negotation" {{ old('status', $editData->status) == 'negotation' ? 'selected' : '' }}>Negotation</option>
                                    <option value="converted" {{ old('status', $editData->status) == 'converted' ? 'selected' : '' }}>Converted</option>
                                    <option value="closedlost" {{ old('status', $editData->status) == 'closedlost' ? 'selected' : '' }}>Closed Lost</option>
                                    <option value="onhold" {{ old('status', $editData->status) == 'onhold' ? 'selected' : '' }}>On Hold</option>
                                    <option value="delivered" {{ old('status', $editData->status) == 'delivered' ? 'selected' : '' }}>Delivered</option>
                                    <option value="completed" {{ old('status', $editData->status) == 'completed' ? 'selected' : '' }}>Completed</option>
                                </select>
                            </div>

                        </div>

                        <!-- Buttons -->
                        <div class="mt-4 d-flex justify-content-end gap-2">
                            <a href="{{ route('enquiry') }}" class="btn btn-secondary">Cancel</a>
                            <button type="submit" class="btn btn-primary">Update</button>
                        </div>

                    </form>

                </div>
            </div>
        </div>

    </div>

    @livewireScripts

    <!-- Bootstrap Bundle JS (with Popper) -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
