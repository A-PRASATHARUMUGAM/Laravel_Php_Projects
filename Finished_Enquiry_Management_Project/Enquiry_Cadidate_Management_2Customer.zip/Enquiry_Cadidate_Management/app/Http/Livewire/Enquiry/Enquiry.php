<?php

namespace App\Http\Livewire\Enquiry;

use Livewire\Component;


class Enquiry extends Component
{


}
