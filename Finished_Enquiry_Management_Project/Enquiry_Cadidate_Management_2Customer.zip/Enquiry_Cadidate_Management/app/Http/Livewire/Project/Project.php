<?php

namespace App\Http\Livewire\Project;

use Livewire\Component;

class Project extends Component
{
    public function render()
    {
        return view('livewire.project.project');
    }
}
