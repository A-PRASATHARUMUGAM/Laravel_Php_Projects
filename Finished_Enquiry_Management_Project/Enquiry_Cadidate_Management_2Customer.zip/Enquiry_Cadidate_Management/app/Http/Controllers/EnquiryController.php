<?php

namespace App\Http\Controllers;

use App\Http\Livewire\Enquiry\Enquiry;
use Illuminate\Http\Request;

use App\Models\Enquirydetail;

class EnquiryController extends Controller
{ 


public function latestenquiry()
{
    // Counts
    $totalCount      = Enquirydetail::count();
    $interestedCount = Enquirydetail::where('status', 'interested')->count();
    $convertedCount  = Enquirydetail::where('status', 'converted')->count();
    $followupCount   = Enquirydetail::where('status', 'followup')->count();

    // Latest 10 enquiries
    $latestdata = Enquirydetail::latest()->take(10)->get();

    return view('livewire.dashboard.dashboard', compact(
        'totalCount',
        'interestedCount',
        'convertedCount',
        'followupCount',
        'latestdata'
    ));
}

    //Store Data
    public function store(Request $request)
    {

        $request->validate([
            'name'        => 'required|string|max:255',
            'email'       => 'required|unique:enquirydetails,email|email|max:255',
            'mobile'      => 'required|numeric|digits:10',
            'companyname' => 'nullable|string|max:255',
            'projectreq'  => 'nullable|string',
            'status'      => 'required|string',
        ]);

        Enquirydetail::create($request->all());

        
        return redirect()->back()->withMessage('success', 'Enquiry created successfully.');
      
    }



//show all data 
public function index(){

       $data = Enquirydetail::orderBy('id','desc')->get();
       return view('livewire.enquiry.enquiry',compact(
        'data'
       ));
}

public function show($id)
{
    $enquiry = Enquirydetail::findOrFail($id);

    return view('livewire.enquiry.view', compact('enquiry'));
}


public function edit(string $id){

   $editData=Enquirydetail::find($id);

    return view('livewire.enquiry.edit',compact('editData'));
}

public function update(Request $request, string $id)
{
    $validated = $request->validate([
        'name'        => 'required|string|max:255',
        'email'       => 'required|email|max:255',
        'mobile'      => 'required|string|max:20',
        'companyname' => 'nullable|string|max:255',
        'projectreq'  => 'nullable|string',
        'status'      => 'required|string',
    ]);

    $enquiry = Enquirydetail::findOrFail($id);
    $enquiry->update($validated);
    return redirect()->route('enquiry')->withSuccess('success', 'Enquiry updated successfully!');
}



public function destroy($id)
{
    $enquiry = Enquirydetail::findOrFail($id);
    $enquiry->delete();

    return redirect()->back()->with('success', 'Enquiry deleted successfully.');
}


 // Customer get route  
    public function create() {
        return view('livewire.enquiry.customer'); // Blade file
    }

 //Customer Store Data
    public function customstore(Request $request)
    {

        $request->validate([
            'name'        => 'required|string|max:255',
            'email'       => 'required|unique:enquirydetails,email|email|max:255',
            'mobile'      => 'required|numeric|digits:10',
            'companyname' => 'nullable|string|max:255',
            'projectreq'  => 'nullable|string',
            'status'      => 'required|string',
        ]);

        Enquirydetail::create($request->all());
      
        return redirect()->back()->withMessage('success', 'Enquiry created successfully.');

 
    }


}





