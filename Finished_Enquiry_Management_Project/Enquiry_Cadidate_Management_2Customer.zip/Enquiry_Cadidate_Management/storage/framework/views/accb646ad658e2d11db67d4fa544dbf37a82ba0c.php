              
         
            <!-- Add Enquiry Modal start -->
            <div class="modal fade" id="addEnquiryModal" tabindex="-1" aria-labelledby="addEnquiryLabel" aria-hidden="true">
              <div class="modal-dialog modal-lg">

                <!-- Form start -->
                <form class="modal-content" wire:submit.prevent="store" >
                  <?php echo csrf_field(); ?> 
                  <div class="modal-header">
                    <h5 class="modal-title" id="addEnquiryLabel">Add Enquiry</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                  </div>

                  <div class="modal-body">
                    <div class="row g-3">
                      
                      <!-- Name -->
                      <div class="col-md-6 form-group has-validation">
                        <label for="enquiryName" class="form-label">Name</label>
                        <input type="text" wire:model="name" name="name" class="form-control" id="enquiryName" placeholder="Enter name" required>
                      </div>
                        <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <span class="text-danger"><?php echo e($message); ?></span>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                      <!-- Email -->
                      <div class="col-md-6">
                        <label for="enquiryEmail" class="form-label">Email</label>
                        <input type="email" wire:model="email" name="email" class="form-control" id="enquiryEmail" placeholder="Enter email" required>
                      </div>
                          <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <span class="text-danger"><?php echo e($message); ?></span>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                      <!-- Mobile -->
                      <div class="col-md-6">
                        <label for="enquiryMobile" class="form-label">Mobile</label>
                        <input 
                          type="text" 
                          wire:model="mobile"
                          name="mobile" 
                          class="form-control" 
                          id="enquiryMobile" 
                          placeholder="Enter 10-digit mobile number" 
                          pattern="[0-9]{10}" 
                          minlength="10" 
                          maxlength="10" 
                          required
                        >
                        <div class="invalid-feedback">Mobile number must be exactly 10 digits.</div>
                      </div>
                         <?php $__errorArgs = ['mobile'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <span class="text-danger"><?php echo e($message); ?></span>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                      <!-- Company Name -->
                      <div class="col-md-6">
                        <label for="enquiryCompany" class="form-label">Company Name</label>
                        <input type="text" wire:model="companyname" name="companyname" class="form-control" id="enquiryCompany" placeholder="Enter company name">
                      </div>

                      <!-- Project Requirement -->
                      <div class="col-12">
                        <label for="enquiryProject" class="form-label">Project Requirement</label>
                        <textarea name="projectreq" wire:model="projectreq" class="form-control" id="enquiryProject" rows="3" placeholder="Describe the project"></textarea>
                      </div>

                      <!-- Status -->
                      <div class="col-md-6">
                        <label for="enquiryStatus" class="form-label">Status</label>
                        <select name="status" wire:model="status" class="form-select" id="enquiryStatus" required>
                          <option selected disabled>Select status</option>
                          <option value="new">New</option>
                          <option value="contacted">Contacted</option>
                          <option value="interested">Interested</option>
                          <option value="followup">Follow Up</option>
                          <option value="needmoreinfo">Need More Info</option>
                          <option value="proposalsent">Proposal Sent</option>
                          <option value="negotation">Negotation</option>
                          <option value="converted">Converted</option>
                          <option value="closedlost">Closed Lost</option>
                          <option value="onhold">On Hold</option>
                          <option value="delivered">Delivered</option>
                          <option value="completed">Completed</option>

                        </select>
                      </div>

                    </div>
                  </div>

                  <!-- Footer -->
                  <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                    <button  type="submit"  class="btn btn-primary">Save Enquiry</button>
                  </div>

                </form>
                <!-- Form end -->

              </div>
            </div>
            <!-- Add Enquiry Modal end --><?php /**PATH D:\Prasath_Program\Genx_Project\Enquiry_Cadidate_Management\Enquiry_Cadidate_Management\resources\views/livewire/enquiry/create.blade.php ENDPATH**/ ?>