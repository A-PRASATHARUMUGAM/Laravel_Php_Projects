<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Welcome Page </title>
    <?php echo \Livewire\Livewire::styles(); ?>

</head>    

<body>
    <div class="Main-Container">
        <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('auth.login')->html();
} elseif ($_instance->childHasBeenRendered('uzxOcmL')) {
    $componentId = $_instance->getRenderedChildComponentId('uzxOcmL');
    $componentTag = $_instance->getRenderedChildComponentTagName('uzxOcmL');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('uzxOcmL');
} else {
    $response = \Livewire\Livewire::mount('auth.login');
    $html = $response->html();
    $_instance->logRenderedChild('uzxOcmL', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>      
    </div>

     <?php echo \Livewire\Livewire::scripts(); ?>

</body>
</html><?php /**PATH D:\Prasath_Program\Genx_Project\Enquiry_Cadidate_Management\Enquiry_Cadidate_Management\resources\views/app.blade.php ENDPATH**/ ?>