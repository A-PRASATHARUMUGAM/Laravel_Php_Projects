<!DOCTYPE html>
<html lang="en">
  <!-- [Head] start -->

  <head>
    <meta charset="utf-8">
    <title>Enquire Management</title>
    <!-- [Meta] -->
    <meta name="keywords" content="Bootstrap admin template, Dashboard UI Kit, Dashboard Template, Backend Panel, react dashboard, angular dashboard">
    <meta name="author" content="Codedthemes">

    <!-- [Favicon] icon -->
    <link rel="icon" href="../assets/images/favicon.svg" type="image/x-icon">
 <!-- [Google Font : Public Sans] icon -->
<link href="https://fonts.googleapis.com/css2?family=Inter:wght@700..700&amp;display=swap" rel="stylesheet">
<!-- [phosphor Icons] https://phosphoricons.com/ -->
<link rel="stylesheet" href="../assets/fonts/phosphor/duotone/style.css">
<!-- [Tabler Icons] https://tablericons.com -->
<link rel="stylesheet" href="../assets/fonts/tabler-icons.min.css">
<!-- [Feather Icons] https://feathericons.com -->
<link rel="stylesheet" href="../assets/fonts/feather.css">
<!-- [Font Awesome Icons] https://fontawesome.com/icons -->
<link rel="stylesheet" href="../assets/fonts/fontawesome.css">
<!-- [Material Icons] https://fonts.google.com/icons -->
<link rel="stylesheet" href="../assets/fonts/material.css">
<!-- [Template CSS Files] -->
<link rel="stylesheet" href="../assets/css/style.css" id="main-style-link">

<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.0/font/bootstrap-icons.css">

  </head>
  <!-- [Head] end -->
  <!-- [Body] Start -->

  <body data-pc-preset="preset-1" data-pc-sidebar-theme="dark" data-pc-header-theme="light" data-pc-sidebar-caption="true" data-pc-direction="ltr" data-pc-theme="light">
    <!-- [ Pre-loader ] start -->
<div class="loader-bg">
  <div class="pc-loader">
    <div class="loader-fill"></div>
  </div>
</div>
<!-- [ Pre-loader ] End -->


 <!-- [ Sidebar Menu ] start -->
<nav class="pc-sidebar">
  <div class="navbar-wrapper">
    <div class="m-header">
      <a href="../dashboard/index.html" class="b-brand text-primary">
        <!-- ========   Change your logo from here   ============ -->
        <img src="../assets/images/logo-white.svg" alt="logo image" class="logo-lg" />
      </a>
    </div>

    <div class="navbar-content">
      <ul class="pc-navbar">
        <li class="pc-item pc-caption">
          <label>Navigation</label>
        </li>

        <!-- Dashbaord  -->
        <li class="pc-item">
          <a href="<?php echo e(route('enquiry.latestenquiry')); ?>" class="pc-link">
            <span class="pc-micon">
              <i class="material-icons-two-tone">home</i>
            </span>
            <span class="pc-mtext">Dashboard</span>
          </a>

        </li>

          <!-- Enquiry -->
            <li class="pc-item">
                <a href="<?php echo e(route('enquiry')); ?>" class="pc-link d-flex align-items-center">
                    <span class="pc-micon d-flex align-items-center justify-content-center">
                        <i class="bi bi-card-checklist"></i>
                    </span>
                    <span class="pc-mtext ms-2">Enquiry</span>
                </a>
              </li>
    

              <!-- Project   -->
                    <li class="pc-item">
                <a href="#" class="pc-link d-flex align-items-center">
                    <span class="pc-micon d-flex align-items-center justify-content-center">
                    <i class="bi bi-globe"></i>
                    </span>
                    <span class="pc-mtext ms-2">Project </span>
                </a>
              </li>

        <!-- Logout   -->
             <li class="pc-item " style="margin-top: 355px;">
                <a href="logout" class="pc-link d-flex align-items-center">
                    <span class="pc-micon d-flex align-items-center justify-content-center">
                      <i class="bi bi-box-arrow-left"></i>
                    </span>
                    <span class="pc-mtext ms-2">Logout</span>
                </a>
              </li>
  
      </ul>
     
    </div>
  </div>
</nav>
<!-- [ Sidebar Menu ] end -->



 <!-- [ Header Topbar ] start -->
<header class="pc-header">
  <div class="header-wrapper">
    <!-- [Mobile Media Block] start -->
      <div class="me-auto pc-mob-drp">
        <ul class="list-unstyled">
          <!-- ======= Menu collapse Icon ===== -->
          <li class="pc-h-item pc-sidebar-collapse">
            <a href="#" class="pc-head-link ms-0" id="sidebar-hide">
              <i class="material-icons-two-tone">menu</i>
            </a>
          </li>
          <li class="pc-h-item pc-sidebar-popup">
            <a href="#" class="pc-head-link ms-0" id="mobile-collapse">
              <i class="material-icons-two-tone">menu</i>
            </a>
          </li>
          <li class="dropdown pc-h-item d-none d-md-flex">
            <a
              class="pc-head-link active pc-head-link-text dropdown-toggle arrow-none me-0"
              data-bs-toggle="dropdown"
              href="#"
              role="button"
              aria-haspopup="false"
              aria-expanded="false"
            >
              Level
            </a>
            <div class="dropdown-menu pc-h-dropdown">
              <a href="#!" class="dropdown-item">
                <i class="material-icons-two-tone">account_circle</i>
                <span>My Account</span>
              </a>
              <a href="#!" class="dropdown-item">
                <i class="material-icons-two-tone">settings</i>
                <span>Settings</span>
              </a>
              <a href="#!" class="dropdown-item">
                <i class="material-icons-two-tone">support</i>
                <span>Support</span>
              </a>
              <a href="#!" class="dropdown-item">
                <i class="material-icons-two-tone">https</i>
                <span>Lock Screen</span>
              </a>
              <a href="#!" class="dropdown-item">
                <i class="material-icons-two-tone">chrome_reader_mode</i>
                <span>Logout</span>
              </a>
            </div>
          </li>
        </ul>
      </div><!-- [Mobile Media Block end] -->
<div class="ms-auto">
  <ul class="list-unstyled">
    <li class="dropdown pc-h-item">
      <a
        class="pc-head-link dropdown-toggle arrow-none me-0"
        data-bs-toggle="dropdown"
        href="#"
        role="button"
        aria-haspopup="false"
        aria-expanded="false"
      >
        <i class="material-icons-two-tone">notifications_active</i>
        <span class="badge bg-danger pc-h-badge">3</span>
      </a>
      <div class="dropdown-menu dropdown-notification dropdown-menu-end pc-h-dropdown">
        <div class="dropdown-header d-flex align-items-center justify-content-between">
          <h4 class="m-0">Notifications</h4>
          <ul class="list-inline ms-auto mb-0">
            <li class="list-inline-item">
              <a href="#" class="avtar avtar-s btn-link-hover-primary">
                <i class="ti ti-arrows-diagonal f-18"></i>
              </a>
            </li>
            <li class="list-inline-item">
              <a href="#" class="avtar avtar-s btn-link-hover-danger">
                <i class="ti ti-x f-18"></i>
              </a>
            </li>
          </ul>
        </div>
        <div class="dropdown-body text-wrap header-notification-scroll position-relative" style="max-height: calc(100vh - 235px)">
          <ul class="list-group list-group-flush">
            <li class="list-group-item">
              <p class="text-span">Today</p>
              <div class="d-flex">
                <div class="flex-shrink-0">
                  <div class="avtar avtar-s bg-light-danger">
                    <i class="ph-duotone ph-user f-18"></i>
                  </div>
                </div>
                <div class="flex-grow-1 ms-3">
                  <div class="d-flex">
                    <div class="flex-grow-1 me-3 position-relative">
                      <h5 class="mb-0 text-truncate">Challenge invitation</h5>
                    </div>
                    <div class="flex-shrink-0">
                      <span class="text-sm text-muted">12 hour ago</span>
                    </div>
                  </div>
                  <p class="position-relative text-muted mt-1 mb-2">
                    <br />
                    <span class="text-truncate">
                      <strong>Jonny aber</strong>
                      invites to join the challenge
                    </span>
                  </p>
                  <button class="btn btn-sm rounded-pill btn-outline-secondary me-2">Decline</button>
                  <button class="btn btn-sm rounded-pill btn-primary">Accept</button>
                </div>
              </div>
            </li>
            <li class="list-group-item">
              <div class="d-flex">
                <div class="flex-shrink-0">
                  <div class="avtar avtar-s bg-light-info">
                    <i class="ph-duotone ph-notebook f-18"></i>
                  </div>
                </div>
                <div class="flex-grow-1 ms-3">
                  <div class="d-flex">
                    <div class="flex-grow-1 me-3 position-relative">
                      <h5 class="mb-0 text-truncate">Forms</h5>
                    </div>
                    <div class="flex-shrink-0">
                      <span class="text-sm text-muted">2 hour ago</span>
                    </div>
                  </div>
                  <p class="position-relative text-muted mt-1 mb-2">
                    Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard
                    dummy text ever since the 1500s.
                  </p>
                </div>
              </div>
            </li>
          </ul>
        </div>
        <div class="dropdown-footer">
          <div class="row g-3">
            <div class="col-6">
              <div class="d-grid"><button class="btn btn-primary">Archive all</button></div>
            </div>
            <div class="col-6">
              <div class="d-grid"><button class="btn btn-outline-secondary">Mark all as read</button></div>
            </div>
          </div>
        </div>
      </div>
    </li>
    <li class="dropdown pc-h-item header-user-profile">
      <a
        class="pc-head-link dropdown-toggle arrow-none me-0"
        data-bs-toggle="dropdown"
        href="#"
        role="button"
        aria-haspopup="false"
        data-bs-auto-close="outside"
        aria-expanded="false"
      >
        <img src="../assets/images/user/avatar-2.jpg" alt="user-image" class="user-avtar" />
        <span class="ms-2">
          <span class="user-name"><?php echo e(auth()->user()->name); ?></span>
          <span class="user-desc">Administrator</span>
        </span>
      </a>
      <div class="dropdown-menu dropdown-user-profile dropdown-menu-end pc-h-dropdown">
        <div class="dropdown-header d-flex align-items-center justify-content-between">
          <h4 class="m-0">Profile</h4>
        </div>
        <div class="dropdown-body">
          <div class="profile-notification-scroll position-relative" style="max-height: calc(100vh - 225px)">
            <ul class="list-group list-group-flush w-100">
              <li class="list-group-item">
                <div class="d-flex align-items-center">
                  <div class="flex-shrink-0">
                    <img src="../assets/images/user/avatar-2.jpg" alt="user-image" class="wid-50 rounded-circle" />
                  </div>
                  <div class="flex-grow-1 mx-3">
                    <h5 class="mb-0">Carson Darrin</h5>
                    <a class="text-sm link-secondary" href="mailto:carson.darrin@company.io">carson.darrin@company.io</a>
                  </div>
                  <a
                    href="https://codedthemes.com/item/dashboardkit-bootstrap-5-admin-template/"
                    target="_blank"
                    class="badge bg-primary rounded"
                  >
                    PRO
                  </a>
                </div>
              </li>
              <li class="list-group-item">
                <a href="#" class="dropdown-item">
                  <span class="d-flex align-items-center">
                    <i class="ph-duotone ph-key"></i>
                    <span>Change password</span>
                  </span>
                </a>
                <a href="#" class="dropdown-item">
                  <span class="d-flex align-items-center">
                    <i class="ph-duotone ph-envelope-simple"></i>
                    <span>Recently mail</span>
                  </span>
                  <div class="user-group">
                    <img src="../assets/images/user/avatar-1.jpg" alt="user-image" class="avtar" />
                    <img src="../assets/images/user/avatar-2.jpg" alt="user-image" class="avtar" />
                    <img src="../assets/images/user/avatar-3.jpg" alt="user-image" class="avtar" />
                  </div>
                </a>
                <a href="#" class="dropdown-item">
                  <span class="d-flex align-items-center">
                    <i class="ph-duotone ph-calendar-blank"></i>
                    <span>Schedule meetings</span>
                  </span>
                </a>
              </li>
            </ul>
          </div>
        </div>
      </div>
    </li>
  </ul>
</div>
</div>
</header>
<!-- [ Header ] end -->



            <!-- [ Main Content ] start -->
            <div class="pc-container">

              <div class="pc-content">


                <!-- [ breadcrumb ] start -->
                <div class="page-header">
                  <div class="page-block">
                    <div class="row align-items-center g-0">
                      <div class="col-sm-auto">
                        <div class="page-header-title">
                          <h5 class="mb-0">Enquiry</h5>
                        </div>
                      </div>
                      <div class="col-sm-auto">
                        <ul class="breadcrumb">
                          <li class="breadcrumb-item"><a href="javascript: void(0)">Home</a></li>
                          <li class="breadcrumb-item"><a href="javascript: void(0)">Elements</a></li>
                          <li class="breadcrumb-item" aria-current="page">Enquiry</li>
                        </ul>
                      </div>
                    </div>
                  </div>
                </div>
                <!-- [ breadcrumb ] end -->
                
            <!-- [ Main Content ] start -->
            
            <div class="row">
            
                <!-- customer-section start -->
          <div class="">

            <!--Enquiry Details start -->
            <div class="card feed-card">
              <!-- Enquiry Header -->
              <div class="card-header py-3 d-flex justify-content-between align-items-center">
                <p class="fw-bold m-0">Enquiry Details</p>
                <button type="button" class="btn btn-primary py-1" data-bs-toggle="modal" data-bs-target="#addEnquiryModal"> Add Enquiry</button>
              </div>
              <!-- Enquiry Header end -->

                          <!-- Enquiry Data start -->
                          <div class="table-responsive feed-scroll" style="max-height: 500px; overflow-y: auto; position: relative;">
                            <table class="table table-bordered table-hover mb-0 fixed-header">
                              <thead class="table-light position-sticky top-0">
                                <tr>
                                  <th style="width:50px">No</th>
                                  <th>Name</th>
                                  <th>Mobile</th>
                                  <th>Status</th>
                                  <th style="width:200px">Action</th>
                                </tr>
                              </thead>
                              <tbody>


                                <?php $__empty_1 = true; $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $viewdata): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                  <tr>
                                <td><?php echo e($viewdata->id); ?></td>
                                <td><?php echo e($viewdata->name); ?></td>
                                <td><?php echo e($viewdata->mobile); ?></td>
                                <td><?php echo e($viewdata->status); ?></td>
                      <td>
                      
                 
                         <a href="<?php echo e(route('enquiry.show',$viewdata->id)); ?>"  class="btn btn-info btn-sm">View </a>
                         <a href="<?php echo e(route('enquiry.edit',$viewdata->id)); ?>"  class="btn btn-sm btn-warning">Edit </a>
                      
                       <a href="<?php echo e(route('enquiry.delete', $viewdata->id)); ?>" 
                        onclick="return confirm('Are you sure you want to delete this enquiry?');" 
                        class="btn btn-danger btn-sm">
                        Delete
                        </a>

                                                  
                          </td>
                                             
                </tr>
                
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <tr>
                    <td colspan="7" class="text-center">No Enquiries Found</td>
                </tr>
              <?php endif; ?>
                       
                                <!-- Repeat for other rows -->
                              </tbody>
                            </table>
                          </div>
                          <!-- Enquiry Data end -->

            </div>
            <!--Enquiry Details end -->

                
                           
              <!-- Add Enquiry Modal start -->
            <div class="modal fade" id="addEnquiryModal" tabindex="-1" aria-labelledby="addEnquiryLabel" aria-hidden="true">
              <div class="modal-dialog modal-lg">


                <!-- Form start -->
                <form class="modal-content" method="POST" action="<?php echo e(route('enquiry.store')); ?>" >
                  <?php echo csrf_field(); ?> 
                  <div class="modal-header">
                    <h5 class="modal-title" id="addEnquiryLabel">Add Enquiry</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                  </div>

                  <div class="modal-body">
                    <div class="row g-3">
                      
                      <!-- Name -->
                      <div class="col-md-6 form-group has-validation">
                        <label for="enquiryName" class="form-label">Name</label>
                        <input type="text"  name="name" class="form-control" id="enquiryName" placeholder="Enter name" value="<?php echo e(old('name')); ?>" required>
                      </div>

                      
                        <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <div class="alert alert-danger"><?php echo e($message); ?></div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                      
                      <!-- Email -->
                      <div class="col-md-6">
                        <label for="enquiryEmail" class="form-label">Email</label>
                        <input type="email"  name="email" class="form-control" id="enquiryEmail" placeholder="Enter email"  value="<?php echo e(old('email')); ?>" required >
                      </div>
                      <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                      <div class="alert alert-danger"><?php echo e($message); ?></div>
                      <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        
                      <!-- Mobile -->
                      <div class="col-md-6">
                        <label for="enquiryMobile" class="form-label">Mobile</label>
                        <input 
                          type="text" 
                          wire:model="mobile"
                          name="mobile" 
                          class="form-control" 
                          id="enquiryMobile" 
                          placeholder="Enter 10-digit mobile number" 
                          pattern="[0-9]{10}" 
                          minlength="10" 
                          maxlength="10" 
                          value="<?php echo e(old('mobile')); ?>"
                          required
                        >
                    
                      </div>
                      <?php $__errorArgs = ['mobile'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                      <div class="alert alert-danger"><?php echo e($message); ?></div>
                      <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                       

                      <!-- Company Name -->
                      <div class="col-md-6">
                        <label for="enquiryCompany" class="form-label">Company Name</label>
                        <input type="text" wire:model="companyname" name="companyname" class="form-control" id="enquiryCompany" 
                        value="<?php echo e(old('companyname')); ?>"
                        placeholder="Enter company name">
                      </div>
                      <?php $__errorArgs = ['companyname'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                      <div class="alert alert-danger"><?php echo e($message); ?></div>
                      <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>


                      <!-- Project Requirement -->
                      <div class="col-12">
                        <label for="enquiryProject" class="form-label">Project Requirement</label>
                        <textarea name="projectreq" class="form-control" id="enquiryProject" rows="3"
                         value="<?php echo e(old('projectreq')); ?>"
                        placeholder="Describe the project"></textarea>
                      </div>
                      <?php $__errorArgs = ['projectreq'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                      <div class="alert alert-danger"><?php echo e($message); ?></div>
                      <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                      <!-- Status -->
                      <div class="col-md-6">
                        <label for="status" class="form-label">Status</label>
                        <select name="status" 
                          value="<?php echo e(old('status')); ?>"
                         class="form-select">
                          <option selected disabled>Select status</option>
                          <option value="new">New</option>
                          <option value="contacted">Contacted</option>
                          <option value="interested">Interested</option>
                          <option value="followup">Follow Up</option>
                          <option value="needmoreinfo">Need More Info</option>
                          <option value="proposalsent">Proposal Sent</option>
                          <option value="negotation">Negotation</option>
                          <option value="converted">Converted</option>
                          <option value="closedlost">Closed Lost</option>
                          <option value="onhold">On Hold</option>
                          <option value="delivered">Delivered</option>
                          <option value="completed">Completed</option>

                        </select>
                      </div>
                      <?php $__errorArgs = ['status'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                      <div class="alert alert-danger"><?php echo e($message); ?></div>
                      <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                    </div>
                  </div>

                  <!-- Footer -->
                  <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                    <button type="submit" class="btn btn-primary">Save Enquiry</button>
                  </div>

                </form>
                <!-- Form end -->

              </div>
            </div>
            <!-- Add Enquiry Modal end -->



      
                </div>
                <!-- customer-section end -->

            </div>


      </div>
      
    </div>
    <!-- [ Main Content ] end -->


 <!-- Required Js -->
<script src="../assets/js/plugins/popper.min.js"></script>
<script src="../assets/js/plugins/simplebar.min.js"></script>
<script src="../assets/js/plugins/bootstrap.min.js"></script>
<script src="../assets/js/fonts/custom-font.js"></script>
<script src="../assets/js/pcoded.js"></script>
<script src="../assets/js/plugins/feather.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
  </body>
  <!-- [Body] end -->
</html>
<?php /**PATH D:\Prasath_Program\Genx_Project\Enquiry_Cadidate_Management\Enquiry_Cadidate_Management\resources\views/livewire/enquiry/enquiry.blade.php ENDPATH**/ ?>