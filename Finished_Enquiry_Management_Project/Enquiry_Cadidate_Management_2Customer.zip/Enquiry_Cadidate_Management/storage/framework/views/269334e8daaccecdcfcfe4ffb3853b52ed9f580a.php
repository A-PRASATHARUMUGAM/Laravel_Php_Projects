<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link rel="stylesheet" href="<?php echo e(url('assets/css/style.css')); ?>" id="main-style-link">
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- Bootstrap Icons -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.0/font/bootstrap-icons.css">
    <title>View Page</title>
</head>    

<body>
    <div class="Main-Container py-5">

        <!-- Enquiry Details Section -->
        <div class="container-fluid">
            <div class="card shadow-sm">
                <div class="card-header">
                    <h5 class="mb-0">Enquiry Details</h5>
                </div>
                <div class="card-body">
                    <div class="row g-3">
                        <div class="col-md-6 d-flex">
                            <div class="fw-bold me-2">No:</div>
                            <div> <?php echo e($enquiry->id); ?></div>
                        </div>
                        <div class="col-md-6 d-flex">
                            <div class="fw-bold me-2">Name:</div>
                            <div><?php echo e($enquiry->name); ?></div>
                        </div>
                        <div class="col-md-6 d-flex">
                            <div class="fw-bold me-2">Email:</div>
                            <div><?php echo e($enquiry->email); ?></div>
                        </div>
                        <div class="col-md-6 d-flex">
                            <div class="fw-bold me-2">Mobile:</div>
                            <div><?php echo e($enquiry->mobile); ?></div>
                        </div>
                        <div class="col-md-6 d-flex">
                            <div class="fw-bold me-2">Company:</div>
                            <div><?php echo e($enquiry->companyname); ?></div>
                        </div>
                        <div class="col-md-6 d-flex">
                            <div class="fw-bold me-2">Status:</div>
                            <div><?php echo e($enquiry->status); ?></div>
                        </div>
                        <div class="col-12 d-flex">
                            <div class="fw-bold me-2">Project Requirement:</div>
                            <div><?php echo e($enquiry->projectreq); ?></div>
                        </div>
                        <div class="col-12 d-flex">
                            <div class="fw-bold me-2">Created At:</div>
                            <div> <?php echo e($enquiry->created_at->format('d-m-Y H:i A')); ?></div>
                        </div>
                    </div>

                    <!-- Divider -->
                    <hr class="my-4">

                    <!-- Status Details Table -->
                    <h6 class="mb-3">Status Details</h6>
                    <div class="table-responsive">
                        <table class="table table-bordered table-sm align-middle">
                            <thead class="table-light">
                                <tr>
                                    <th>Status</th>
                                    <th>Updated Time</th>
                                </tr>
                            </thead>
                            <tbody>
                                <tr>
                                    <td><?php echo e($enquiry->status); ?></td>
                                    <td><?php echo e($enquiry->updated_at->format('d-m-Y H:i A')); ?></td>
                                </tr>
                            </tbody>
                        </table>
                    </div>

                    <!-- Close Button -->
                    <div class="mt-4 text-end">
                        <a href="<?php echo e(route('enquiry')); ?>" class="btn btn-secondary">
                            Close
                        </a>
                    </div>

                </div>
            </div>
        </div>

    </div>

    <?php echo \Livewire\Livewire::scripts(); ?>


    <!-- Bootstrap Bundle JS (with Popper) -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
<?php /**PATH D:\Prasath_Program\Genx_Project\Enquiry_Cadidate_Management\Enquiry_Cadidate_Management\resources\views/livewire/enquiry/view.blade.php ENDPATH**/ ?>