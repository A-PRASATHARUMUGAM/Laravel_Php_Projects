<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Customer Enquiry</title>
  
  <!-- Bootstrap CSS -->
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">

  <!-- Bootstrap Icons -->
  <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.0/font/bootstrap-icons.css" rel="stylesheet">
</head>
<body class="bg-light">


<!-- Add Enquiry Form -->
<div class="container my-5">
  <div class="modal-dialog modal-lg mx-auto">
    
        <!-- Success Message -->
    <?php if(session('success')): ?>
      <div class="alert alert-success alert-dismissible fade show" role="alert">
        <?php echo e(session('success')); ?>

        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
      </div>
    <?php endif; ?>

    <!-- Form start -->
    <form action="<?php echo e(route('customer.store')); ?>" method="POST" class="modal-content shadow-lg rounded-4 border-0 p-4"  >
      <?php echo csrf_field(); ?>
      <div class="modal-header border-0 pb-0">
        <h5 class="modal-title fw-bold text-dark">Add Enquiry</h5>
      </div>

      <div class="modal-body pt-3">
        <div class="row g-4">

          <!-- Name -->
          <div class="col-md-6">
            <label for="enquiryName" class="form-label text-secondary fw-semibold small">Name</label>
            <input type="text" name="name" class="form-control form-control-lg rounded-3 shadow-sm" id="enquiryName" placeholder="Enter name" value="<?php echo e(old('name')); ?>" required>
            <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
              <div class="text-danger small mt-1"><?php echo e($message); ?></div>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
          </div>

          <!-- Email -->
          <div class="col-md-6">
            <label for="enquiryEmail" class="form-label text-secondary fw-semibold small">Email</label>
            <input type="email" name="email" class="form-control form-control-lg rounded-3 shadow-sm" id="enquiryEmail" placeholder="Enter email" value="<?php echo e(old('email')); ?>" required>
            <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
              <div class="text-danger small mt-1"><?php echo e($message); ?></div>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
          </div>

          <!-- Mobile -->
          <div class="col-md-6">
            <label for="enquiryMobile" class="form-label text-secondary fw-semibold small">Mobile</label>
            <input type="text" name="mobile" class="form-control form-control-lg rounded-3 shadow-sm" id="enquiryMobile" placeholder="Enter 10-digit mobile number" pattern="[0-9]{10}" minlength="10" maxlength="10" value="<?php echo e(old('mobile')); ?>" required>
            <?php $__errorArgs = ['mobile'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
              <div class="text-danger small mt-1"><?php echo e($message); ?></div>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
          </div>

          <!-- Company Name -->
          <div class="col-md-6">
            <label for="enquiryCompany" class="form-label text-secondary fw-semibold small">Company Name</label>
            <input type="text" name="companyname" class="form-control form-control-lg rounded-3 shadow-sm" id="enquiryCompany" placeholder="Enter company name" value="<?php echo e(old('companyname')); ?>">
            <?php $__errorArgs = ['companyname'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
              <div class="text-danger small mt-1"><?php echo e($message); ?></div>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
          </div>

          <!-- Project Requirement -->
          <div class="col-12">
            <label for="enquiryProject" class="form-label text-secondary fw-semibold small">Project Requirement</label>
            <textarea name="projectreq" class="form-control form-control-lg rounded-3 shadow-sm" id="enquiryProject" rows="4" placeholder="Describe the project"><?php echo e(old('projectreq')); ?></textarea>
            <?php $__errorArgs = ['projectreq'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
              <div class="text-danger small mt-1"><?php echo e($message); ?></div>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
          </div>

          <!-- Status -->
          <div class="col-md-6">
            <label for="status" class="form-label text-secondary fw-semibold small">Status</label>
            <select name="status" class="form-select form-select-lg rounded-3 shadow-sm" id="status">
              <option selected disabled>Select status</option>
              <option value="new">New</option>
              <option value="contacted">Contacted</option>
              <option value="interested">Interested</option>
              <option value="followup">Follow Up</option>
              <option value="needmoreinfo">Need More Info</option>
              <option value="proposalsent">Proposal Sent</option>
              <option value="negotation">Negotation</option>
              <option value="converted">Converted</option>
              <option value="onhold">On Hold</option>
              <option value="delivered">Delivered</option>
              <option value="completed">Completed</option>
            </select>
            <?php $__errorArgs = ['status'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
              <div class="text-danger small mt-1"><?php echo e($message); ?></div>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
          </div>

        </div>
      </div>

      <!-- Footer -->
      <div class="modal-footer border-0 pt-3">
        <a href="<?php echo e(route('login')); ?>" class="btn btn-dark rounded-3 px-4 ">Cancel</a>
        <button type="submit" class="btn btn-primary rounded-3 px-4 m-2">Save Enquiry</button>
      </div>
    </form>
    <!-- Form end -->

  </div>
</div>


  <!-- Bootstrap JS -->
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>

</body>
</html>
<?php /**PATH D:\Prasath_Program\Genx_Project\Enquiry_Cadidate_Management\Enquiry_Cadidate_Management\resources\views/livewire/enquiry/customer.blade.php ENDPATH**/ ?>