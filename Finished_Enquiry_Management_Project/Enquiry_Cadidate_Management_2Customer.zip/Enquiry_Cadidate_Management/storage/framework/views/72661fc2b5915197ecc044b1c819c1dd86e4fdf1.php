<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Welcome Page </title>
    <?php echo \Livewire\Livewire::styles(); ?>

</head>    

<body>
    <div class="Main-Container">
        <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('dashboard.dashboard')->html();
} elseif ($_instance->childHasBeenRendered('ZEbXfOs')) {
    $componentId = $_instance->getRenderedChildComponentId('ZEbXfOs');
    $componentTag = $_instance->getRenderedChildComponentTagName('ZEbXfOs');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('ZEbXfOs');
} else {
    $response = \Livewire\Livewire::mount('dashboard.dashboard');
    $html = $response->html();
    $_instance->logRenderedChild('ZEbXfOs', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
        <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('enquiry.enquiry')->html();
} elseif ($_instance->childHasBeenRendered('twLFv07')) {
    $componentId = $_instance->getRenderedChildComponentId('twLFv07');
    $componentTag = $_instance->getRenderedChildComponentTagName('twLFv07');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('twLFv07');
} else {
    $response = \Livewire\Livewire::mount('enquiry.enquiry');
    $html = $response->html();
    $_instance->logRenderedChild('twLFv07', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>

        
    </div>

     <?php echo \Livewire\Livewire::scripts(); ?>

</body>
</html><?php /**PATH D:\Prasath_Program\Genx_Project\Enquiry_Cadidate_Management\Enquiry_Cadidate_Management\resources\views/welcome.blade.php ENDPATH**/ ?>