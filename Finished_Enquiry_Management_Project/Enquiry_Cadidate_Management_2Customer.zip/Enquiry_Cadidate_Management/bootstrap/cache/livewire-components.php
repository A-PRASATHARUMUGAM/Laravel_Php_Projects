<?php return array (
  'auth.login' => 'App\\Http\\Livewire\\Auth\\Login',
  'auth.register' => 'App\\Http\\Livewire\\Auth\\Register',
  'dashboard.dashboard' => 'App\\Http\\Livewire\\Dashboard\\Dashboard',
  'enquiry.enquiry' => 'App\\Http\\Livewire\\Enquiry\\Enquiry',
  'project.project' => 'App\\Http\\Livewire\\Project\\Project',
);