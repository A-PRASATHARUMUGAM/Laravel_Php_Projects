<?php

use App\Http\Controllers\Auth\LoginController;
use App\Http\Controllers\Auth\RegisterController;
use App\Http\Controllers\Controller;
use App\Http\Controllers\EnquiryController;
use App\Http\Livewire\Enquiry\Enquiry;
use Illuminate\Support\Facades\Route;
use Livewire\Livewire;
;   
Route::view('/register','livewire.auth.register')->middleware('guest')->name('register');

Route::post('/store',[RegisterController::class,'store']);

Route::view('/login','livewire.auth.login')->middleware('guest')->name('login');

Route::get('/', function () {
        return redirect()->route('login');
});

Route::post('/authenticate', [LoginController::class,'authenticate']);

Route::get('/logout',[LoginController::class,'logout']);    


// Enquiry Routes

//Added Data   - > data base to store data
Route::post('/enquiry/store',[EnquiryController::class,'store'])->middleware('auth')->name('enquiry.store');  

// View Data   -> to show all data 
Route::get('/enquiry',[EnquiryController::class,'index'])->middleware('auth')->name('enquiry');


// Latest Enquiry to dashboard -> to view latest 10 data in dashboard and stauts
Route::get('/home', [EnquiryController::class, 'latestenquiry'])->middleware('auth')->name('enquiry.latestenquiry');

// View   -> to show all data 

//show 
Route::get('/enquiry/{id}', [EnquiryController::class,'show'])->middleware('auth')->name('enquiry.show');

//Edit
Route::get('/enquiry/{id}/edit', [EnquiryController::class,'edit'])->middleware('auth')->name('enquiry.edit');

//Put
Route::put('/enquiry/{id}', [EnquiryController::class, 'update'])->middleware('auth')->name('enquiry.update');

//Delete
Route::get('/enquiry/delete/{id}', [EnquiryController::class, 'destroy'])->middleware('auth')->name('enquiry.delete');



//Create route 
Route::get('/customer/enquiry', [EnquiryController::class, 'create'])->name('customer.create');

//Customer Enquiry
Route::post('/customer/enquiry', [EnquiryController::class, 'customstore'])->name('customer.store');


 